# -*- coding: utf-8 -*-
"""
Created on Thu May  9 21:37:26 2019

@author: mv gupta
"""
lists=[1,3,6,78,35,55] 
list1=[12,24,35,24,88,120,155]
li1=set(lists)
li2=set(list1)
li3=list(li1.intersection(li2))
print(li3)
