# -*- coding: utf-8 -*-
"""
Created on Thu May  9 18:51:36 2019

@author: mv gupta
"""

from collections import OrderedDict
od = OrderedDict()
item=[]
price=[]
while True:
    item1=input("Enter item")
    item2=input("Enter prices")
    if not item1:
        break
    item.append(item1)
    price.append(item2)
    
list1=[]
list2=[]
for i in item:
    for j in price:
        if i in list1:
            index1=list1.index(i)
            index2=item.index(i)
            list1[index1]=list2[index1]+price[index2]
        else:
            list1.append(i)
            list2.append(j)
        
    
    
print(list1)

    
    



