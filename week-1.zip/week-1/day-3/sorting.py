# -*- coding: utf-8 -*-
"""
Created on Thu May  9 08:44:26 2019

@author: mv gupta
"""

user=tuple(input