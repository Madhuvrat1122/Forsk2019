# -*- coding: utf-8 -*-
"""
Created on Thu May  9 09:11:13 2019

@author: mv gupta
"""

a=list(map(int,input("Enter no").split()))
print(a)