# -*- coding: utf-8 -*-
"""
Created on Thu May  9 12:54:58 2019

@author: mv gupta
"""

user=list(input("Enter any sentences").split())
dict1={'digits':0,'letter':0}
st="abcdefghijklmnopqrstuvwxyz'
di=01234567
for i in range(len(user)):
    if user[i] in st:
        

