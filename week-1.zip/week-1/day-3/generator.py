# -*- coding: utf-8 -*-
"""
Created on Thu May  9 09:18:44 2019

@author: mv gupta
"""

inp=list(map(int,input("Enter inputs").split(',')))
dict1=tuple(inp)
print(dict1)
print(inp)

