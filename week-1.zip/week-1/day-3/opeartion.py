# -*- coding: utf-8 -*-
"""
Created on Thu May  9 00:09:29 2019

@author: mv gupta
"""
def sum1(a):
    sum_to=0;
    for i in a:
        sum_to=sum_to+i
    print("sum is = {}".format(sum_to))

def mul(a):
    tot=1
    for i in a:
        tot=tot*i
    print("MULTIPLY = {}".format(tot))

def small(a):
    temp=1000
    for i in a:
        if temp>i:
            temp=i
    print("smaller = {}".format(temp))
    
def larger(a):
    temp=0
    for i in a:
        if temp<i:
            temp=i
    print("larger = {}".format(temp))
    
def sorter(a):
    b=sorted(a)
    print("sorted array = {}".format(b))

def duplicate(a):
    b=[]
    for i in a:
        if i not in b:
            b.append(i)
    print(b)
    
def print1(a):
    sum(a)
    mul(a)
    small(a)
    larger(a)
    sorter(a)
    duplicate(a)

   
a=list(map(int,input("Enter numbers").split()))
print1(a)

