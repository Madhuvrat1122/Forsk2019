# -*- coding: utf-8 -*-
"""
Created on Thu May  9 21:42:05 2019

@author: mv gupta
"""

li=[12,24,35,24,88,120,155,88,120,155]
li1=[]
for i in li:
    if i in li1:
        continue
    else:
        li1.append(i)
print(li1)