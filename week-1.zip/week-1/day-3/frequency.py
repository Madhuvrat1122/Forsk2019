# -*- coding: utf-8 -*-
"""
Created on Thu May  9 20:49:59 2019

@author: mv gupta
"""
user=list(input("Enter any string"))
dict1={}
list1=[]
for i in user:
    dict1[i]=0
for i in user:
    if i in user:
        dict1[i]+=1
    else:
        list1.append(user)

print(dict1)
