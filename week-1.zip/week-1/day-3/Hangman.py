# -*- coding: utf-8 -*-
"""
Created on Thu May  9 23:13:13 2019

@author: mv gupta
"""
import random
def hangman_game():
    list1=['alok','gupta','hitesh','soni','mohit','kumar']
    secret_word=random.choice(list1)
    while True:
        guess_word=input("Enter any word form list {}-->".format(list1))
        if guess_word==secret_word:
            print("player wins and computer lose")
            break
        else:
            print("player lose and computer wins")
            choice=input("do you want to quit")
            if choice=="yes":
                break
            else:
                continue
            
hangman_game()
        