# -*- coding: utf-8 -*-
"""
Created on Thu May  9 10:14:33 2019

@author: mv gupta
"""

user=tuple(map(str,input("Enter weeks : ").split(',')))
days=["monday","tuesday","wednesday","thursday","friday","saturday","sunday"]
weeks=list(user)
for index,item in enumerate(days):
    if item not in weeks:
        weeks.insert(index,item)
        
print(tuple(weeks))

        
        
        
        
    
    
       
    