# -*- coding: utf-8 -*-
"""
Created on Thu May  9 11:38:17 2019

@author: mv gupta
"""

def teen_rule(a,counter):
    li=[13,14,17,18,19]
    if a in li:
        a=0
        counter+=1
    return(a,counter)
        
    
dict1={}
i=0
sum=0
counter=0
while i<5: 
    key=input("Enter items-> ")
    value=int(input("Enter quantity"))
    i+=1
    dict1[key]=value
print(dict1)
for key in dict1.values():
    if(counter<3):
        s,counter=teen_rule(key,counter)
        sum+=s
    else:
        sum+=key
print(sum)
    
    
    
