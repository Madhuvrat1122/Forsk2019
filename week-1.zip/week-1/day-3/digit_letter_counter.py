# -*- coding: utf-8 -*-
"""
Created on Thu May  9 21:22:38 2019

@author: mv gupta
"""
dict1={'digit':0,'letter':0}
user=list(input("enter any string").split(' '))
digit=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
number=['0','1','2','3','4','5','6','7','8','9']
for i in user:
    for j in range(len(i)):
        if i[j] in digit:
            dict1['digit']+=1
        elif i[j] in number:
            dict1['letter']+=1

for key,value in dict1.items():
    print(key,value)
