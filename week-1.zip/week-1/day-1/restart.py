# -*- coding: utf-8 -*-
"""
Created on Tue May  7 12:26:16 2019

@author: mv gupta
"""

str1="RESTART"
loc=str1.find("R")
str2=str1[loc+1:]
print(str1[:loc+1]+str2.replace("R","$"))

    
