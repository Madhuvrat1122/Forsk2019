# -*- coding: utf-8 -*-
"""
Created on Tue May  7 12:12:10 2019

@author: mv gupta
"""

import math
dir(math)
help(math)
num=int(input("Enter any number"))
print(math.factorial(num))

