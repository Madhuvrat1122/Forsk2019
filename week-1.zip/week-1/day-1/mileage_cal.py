# -*- coding: utf-8 -*-
"""
Created on Sun May 19 14:58:08 2019

@author: mv gupta
"""

travel=100
fuel=5
distanc=travel/fuel
print(distanc)