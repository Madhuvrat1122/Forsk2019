# -*- coding: utf-8 -*-
"""
Created on Tue May  7 12:49:35 2019

@author: mv gupta
"""

i=0
while i<101:
    if(i%3==0 and i%5==0):
        print("FizzBuzz")
    elif(i%3==0):
        print("Fizz")
    elif(i%5==0):
        print("Buzz")
    else:
        print(i)
    i=i+1
        
        