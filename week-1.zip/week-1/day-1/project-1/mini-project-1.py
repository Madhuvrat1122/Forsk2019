# -*- coding: utf-8 -*-
"""
Created on Tue May  7 23:50:55 2019

@author: mv gupta
"""


# -*- coding: utf-8 -*-
"""
Created on Tue May  7 18:56:07 2019

@author: mv gupta
"""

import random
#first chellenge
secret_number=random.randint(0,10)
guess_number=int(input("Guess any number!!"))
if guess_number==secret_number :
    print("player wins and computer lose")
else:
    print("player lose and computer wins")
    
#second chellenge
print("Guess number is {} and secret number is {}".format(guess_number,secret_number))

#third chellenge
if guess_number==secret_number :
    print("player wins and computer lose")
elif guess_number>secret_number:
    print("TOO HIGH")
elif guess_number<secret_number:
    print("TOO LOW")
    
    
#fourth chelenge
while(True):
    secret_number=random.randint(0,10)
    guess_number=int(input("Guess any number!!"))
    if guess_number==secret_number :
        print("player wins and computer lose")
        break
    else:
        print("you loss!try again")
        continue
    
#fifth chellenge
i=0
while(True and i<6):
    secret_number=random.randint(0,10)
    guess_number=int(input("Guess any number!!"))
    if guess_number==secret_number :
        print("player wins and computer lose")
        break
    else:
        print("you loss!try again")
        i+=1
        continue
    
#sixth chellenge
i=0
while(True and i<6):
    secret_number=random.randint(0,10)
    guess_number=int(input("Guess any number!!"))
    if guess_number==secret_number :
        print("player wins and computer lose")
        break
    else:
        print("you loss!you have only {} chances to win".format(5-i))
        i+=1
        continue
    
#seventh chellenges
i=0
while(True and i<6):
    secret_number=random.randint(0,10)
    guess_number=int(input("Guess any number!!"))
    if guess_number==secret_number :
        print("player wins and computer lose")
        break
    else:
        user=input("you loss!!do u want to play again ")
        if user=="yes":
            continue
        else:
            break;
    
#eight chellenge
while(True):
    try:
        secret_number=random.randint(0,10)
        guess_number=int(input("Guess any number!!"))
    except ValueError:
        print("Not an integer! Try again.")
        continue
    else:
        if guess_number==secret_number :
            print("player wins and computer lose")
            break
        else:
            user=input("you loss!!do u want to play again ")
            if user=="yes":
                continue
            else:
                break
         
   
        
    

    