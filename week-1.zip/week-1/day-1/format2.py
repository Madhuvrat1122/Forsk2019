# -*- coding: utf-8 -*-
"""
Created on Sun May 19 15:37:21 2019

@author: mv gupta
"""
#first format2.py
str1="Welcome to Pink City Jaipur"
str2=str1.replace(" ","*")
print(str2)

#second format3.py
str1="Welcome to Pink City Jaipur"
str2="*".join(str1)
print(str2)