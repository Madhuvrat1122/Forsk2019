# -*- coding: utf-8 -*-
"""
Created on Tue May  7 12:42:19 2019

@author: mv gupta
"""
str1=input("Enter First Name and Last Name-> ")
loc=str1.find(" ")
print(str1[loc+1:]+" "+str1[:loc])