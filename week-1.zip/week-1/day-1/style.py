# -*- coding: utf-8 -*-
"""
Created on Tue May  7 12:20:09 2019

@author: mv gupta
"""

str=input("Enter string")
print(str.upper())
print(str.lower())
print(str.title())