# -*- coding: utf-8 -*-
"""
Created on Sun May 19 15:07:50 2019

@author: mv gupta
"""

first=int(input("Enter First assignment score-> "))
second=int(input("Enter Second assignment score-> "))
third=int(input("Enter Third assignment score-> "))
f1=int(input("Enter First Exam score-> "))
f2=int(input("Enter second Exam score-> "))
final=(first+second+third)*0.1+(f1+f2)*0.35
print(final)