# -*- coding: utf-8 -*-
"""
Created on Tue May  7 12:01:24 2019

@author: mv gupta
"""
for i in range(9):
    if(i==0 or i%2==0):
        print("* "*8)
    else:
        print(" *"*8)
    