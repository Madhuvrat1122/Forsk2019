# -*- coding: utf-8 -*-
"""
Created on Wed May  8 10:25:46 2019

@author: mv gupta
"""
"""list=[]
for i in range(1,21):
    list.append(i)
print(list[0::2])
print(list[1::2])"""

"""def leap(a):
    if a%4==0 or a%400==0 or a!=100:
        return True
    else:
        return False
print(leap(2000))"""

""""def days_in_month(a):
    list1=['january','march','may','july','october','december']
    list2=['april','june','august','november']
    list3=['febuery']
    if a in list1:
        print("31 Days")
    if a in list2:
        print("30 Days")
    if leap(a)=='True':
        print("28 Days")
    if a in list3:
        print("29 Days")

days_in_month('june')"""

"""state_name = [ 'Alabama', 'California', 'Oklahoma', 'Florida']
vowels=['A','a','E','e','I','i','O','o','U','u']
list1=[]
list2=[]
for i in state_name:
    string1=''
    for j in i:
        if j not in vowels:
            string1=string1+j
    list1.append(string1)
    
print(list1)"""

"""i=int(input("Enter any number"))
j=i
for k in range(i):
   print("*"*k)
while(j>0):
   print("*"*j)
   j=j-1"""
   
"""list1=[]
i=0
n=int(input("Enter list of elements"))
while i<n:
    item=input("Enter element of list")
    list1.append(item)
    i=i+1
print(list1)
count=0
for i in range(len(list1)):
    if int(list1[i])>0 
        if list1[i]==list1[i][::-1]:
            count+=1
if count>=1:
    print(True)
else:
    print(False)"""

"""list1=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
item=input("Enter any string")  
list2=[]
list4=[]
list3=item.split()
for i in list3:
    for j in i.lower():
        list2.append(j)
list2.sort()
for i in list2:
    if i not in list4:
        list4.append(i)
if len(list1)>len(list4):
    print("NOT PANGRAM")
else:
    if list4==list1:
        print("PANGRAM")
    else:
        print("NOT PANGRAM")"""
        

"""a=list(map(int,input("Enter numbers").split()))
first=2*a[0]
second=5*a[1]
total=first+second
if total>=a[2]:
    print("True")
else:
    print("False")"""
    
"""num=input("Enter string")
print(num[::-1])"""


        
    
    



            



    

