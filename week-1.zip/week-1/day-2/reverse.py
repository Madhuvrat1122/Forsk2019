# -*- coding: utf-8 -*-
"""
Created on Wed May  8 22:50:47 2019

@author: mv gupta
"""

a=input("Enter any string")
print(a[::-1])

