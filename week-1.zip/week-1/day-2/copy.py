# -*- coding: utf-8 -*-
"""
Created on Fri May 10 09:06:00 2019

@author: mv gupta
"""

fp=open("new.txt","rt")
