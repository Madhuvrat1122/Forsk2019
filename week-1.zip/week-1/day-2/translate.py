# -*- coding: utf-8 -*-
"""
Created on Wed May  8 22:54:15 2019

@author: mv gupta
"""

item=input("Enter any string")
con=['a','e','i','o','u','A','E','I','O','U']
string2=''
list2=[]
item1=item.split()
for i in range(len(item1)):
    list2.clear()
    for j in range(len(item1[i])):
        if item1[i][j] not in con:
            list2.append(item1[i][j]+'o'+item1[i][j])
        else:
            list2.append(item1[i][j])
    for k in range(len(list2)):
        string2+=list2[k]
    string2+=" "
print(string2)
            
       
