# Shopping List App 

"""
Challenge 1
    We are going to make a "Shopping List" app. 
    Run the script to start using it.
    Put new things into the list one at a time
    Enter the word DONE - in all CAPS - to QUIT the program
    And once i quit, I want the app to show me everything thats on my list.

Hint 1
    Step 1: Make a list to hold onto our items.
    Step 2: Print out instructions on how to use the app

    Step 3: Ask for new items
    Step 4: Add new items to our list
    Step 5: Be able to quit the app with DONE

    Step 6: print out the list
"""


#   Make a list to hold onto our items.
shopping_list = []

# Print out instructions on how to use the app
print ("What should we pick up at the store ?")
print ("Enter 'DONE' to stop adding items.")

while True:
    # ask for new items
    new_item = input("> ")

    # be able to quit the app
    if new_item == 'DONE':
        break
    
    # add new items to our list
    shopping_list.append(new_item)

#  print out the list
print("Here’s your list")
for item in shopping_list:
    print ( item )



"""
Challenge 2
    If I type SHOW, 
    I should be able to see what is currently in the list

    If I type HELP, 
    I should be able to see all the help for these special commands

Hint 2
    Step 1: Have a HELP command
    Step 2: Have a SHOW command
    Step 3: Add a function for adding into the list 
    Step 4: Cleanup the code in general
"""
#  print out the list
def show():
    print("Here’s your list")
    for item in shopping_list:
        print ( item )
def Help():
    print("DONE-> It is use to stop Process")
    print("SHOW-> It shows the item in the cart")
        
shopping_list = []

# Print out instructions on how to use the app
print ("What should we pick up at the store ?")
print ("Enter 'DONE' to stop adding items.")

while True:
    # ask for new items
    new_item = input("> ")

    # be able to quit the app
    if new_item == 'SHOW':
        show()
    if new_item == 'DONE':
        break
    if new_item == 'HELP':
        Help()
    
    # add new items to our list
    else:
        shopping_list.append(new_item)





"""

Challenge 3
    User can enter SHOW or Show or show, 
    similar for DONE and HELP, but the program should do the required job

    Show the item in the list serially starting from 1

    Let us accept items using a comma separated string
        
    Also there should be a functionality to add an item at a specific index

    There should be a functionality to remove items from the list at a specific index using REMOVE
    
"""
def Show():
    print("Here’s your list")
    for item in range(len(shopping_list)):
        print ("{} {}".format(item+1,shopping_list[item]))
def Help():
    print("DONE-> It is use to stop Process")
    print("SHOW-> It shows the item in the cart")
def Add():
    user=input("Enter items into your cart => ").split()
    for item in user:
        shopping_list.append(item)
shopping_list=[]
user=[]
file = open('shopping_list.txt', mode='wt')
while(True):
    choice=input("ENTER YOUR CHOICE:- ADD,ADD_INDEX_WISE , HELP , SHOW , DONE , DELETE => ")
    if choice.lower()=='add':
        Add()
    elif choice.lower()=='add_index_wise':
        index=int(input("Enter at which index u want to insert item => "))
        item=input("Enter Item:- ")
        shopping_list.insert(index,item)
    elif choice.lower()=='help':
        Help()
    elif choice.lower()=='show':
        Show()
    elif choice.lower()=='done':
        break
    elif choice.lower()=='delete':
        index=int(input("Enter index which data u want to delete :- "))
        shopping_list.pop(index)
    else:
        print("PLEASE! ENTER ANY CHOICE")
file.write("{} {}\n".format('SNO.','ITEMS'))
for item in range(len(shopping_list)):
    file.write("{} {}\n".format(item+1,shopping_list[item]))
file.close()
    


"""
Challenge 4   
    Do all the exception handling for all the extreme use cases 
"""
file = open('shopping_list.txt', mode='wt')
file.write("{} {}\n".format('SNO.','ITEMS'))
for item in range(len(shopping_list)):
    file.write("{} {}\n".format(item+1,shopping_list[item]))
file.close()
"""
Challenge 5   
    Store the shopping list in a file. 
"""
