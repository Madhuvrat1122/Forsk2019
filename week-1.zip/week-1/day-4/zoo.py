# -*- coding: utf-8 -*-
"""
Created on Fri May 10 10:59:07 2019

@author: mv gupta
"""
import csv
li=[]
di={}
sum=0
with open("zoo.csv") as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=",")
    # row has the list of all columns   
    next(csv_reader)
    for i in csv_reader:
        if(di.get(i[0])):
            di[i[0]]+=int(i[2])
            sum+=int(i[2])
        else:
            di[i[0]]=int(i[2])
            sum+=int(i[2])
            
for i in di:
    with open("zoo.csv") as csv_file:
         csv_reader = csv.reader(csv_file, delimiter=",")
         next(csv_reader)
         for j in csv_reader:
             print(j[0])
             if i in j[0]:
                 print("{} {}".format(j[1],j[2]))
        
        
    
           
print(di)    
print(sum)


    



