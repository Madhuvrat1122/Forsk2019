# -*- coding: utf-8 -*-
"""
Created on Sat May 11 08:55:17 2019

@author: mv gupta
"""

from PIL import Image
import os
img = Image.open("a.jpg")
img = Image.open("a.jpg")
                    # startx, starty,width,height
crop_im = img.crop(box=(0, 0, 160, 204))
crop_im.save('crop_sample1.jpg')

 
# Displays the rotated image
