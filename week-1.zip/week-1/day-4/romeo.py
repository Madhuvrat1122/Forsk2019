# -*- coding: utf-8 -*-
"""
Created on Fri May 10 12:30:08 2019

@author: mv gupta
"""

di={}
li=[]
with open("romeo.txt",mode="rt") as fp:
    item=fp.read()
    print(item)
    li=list(map(str,item.split(" ")))
    print(li)
    for i in li:
        i=i.replace('\n','')
        if i in di:
            di[i]+=1
        else:
            di[i]=1

print(di)

        
        

    