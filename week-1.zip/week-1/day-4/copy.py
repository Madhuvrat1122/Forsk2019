# -*- coding: utf-8 -*-
"""
Created on Fri May 10 09:06:00 2019

@author: mv gupta
"""

fp=open("new.txt","rt")
f1=fp.readlines()
fp.close()

with open("new1.txt","wt") as fp1:
    for i in f1:
        fp1.write(i)
    

    

