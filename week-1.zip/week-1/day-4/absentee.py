# -*- coding: utf-8 -*-
"""
Created on Fri May 10 10:48:48 2019

@author: mv gupta
"""
with open("absentee.txt","wt") as fp:
    while True:
        inp=input("Enter name of student")
        if not inp:
            break
        fp.write(inp+"\n")

        