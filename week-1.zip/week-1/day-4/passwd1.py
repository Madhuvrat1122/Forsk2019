# -*- coding: utf-8 -*-
"""
Created on Fri May 10 13:12:46 2019

@author: mv gupta
"""
li=[]
di={}
with open("passwd.txt",mode="rt") as fp:
    for i in fp.readlines():
        li=list(map(str,i.split(":")))
        di[li[0]]=int(li[2])
    
for key,value in sorted(di.items()):
    print("{} {}".format(key,value))
        

        
        

    
    
    
    