# -*- coding: utf-8 -*-
"""
Created on Fri May 10 13:04:40 2019

@author: mv gupta
"""
name=input("Enter any file name")
with open(name,mode="rt") as fp:
    item=fp.readlines()[-1]
    print(item)

    
    

