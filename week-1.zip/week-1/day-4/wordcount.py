# -*- coding: utf-8 -*-
"""
Created on Fri May 10 22:17:40 2019

@author: mv gupta
"""

di={'char':0,'words':0,'lines':0,'unique':0}
di1={}
fname=input("enter the name of the file:")
infile=open(fname, 'r')
lines=0
words=0
characters=0
for line in infile:
    line = line.strip('\n')
    wordslist=line.split()
    for i in wordslist:
        if i.lower() in di1:
            di1[i.lower()]+=1
        else:
            di1[i.lower()]=1
    lines=lines+1
    words=words+len(wordslist)
    characters=characters+ len(line)
    di['char']=characters
    di['words']=words
    di['lines']=lines
di['unique']=len(di1)
for key,value in di.items():
    print("{} {}".format(key,value))
  
    
    
    
        

    