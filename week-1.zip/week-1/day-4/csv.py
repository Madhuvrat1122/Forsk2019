# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import csv
user=input("Enter file name")
with open(user,"rt") as fp:
    read=csv.reader(fp,delimiter=',')
    for i in read:
        print(i)

