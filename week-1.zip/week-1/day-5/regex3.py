# -*- coding: utf-8 -*-
"""
Created on Sat May 11 11:18:30 2019

@author: mv gupta
"""

import re
user=input("Enter pin number")
if re.findall(r'^[4-6]+[0-9]{15}|^[4-6]+[0-9]{3}\-[0-9]{4}\-[0-9]{4}\-[0-9]{4}',user):
    print(True)
else:
    print(False)
    
   