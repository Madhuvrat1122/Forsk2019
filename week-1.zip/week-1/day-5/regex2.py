# -*- coding: utf-8 -*-
"""
Created on Sat May 11 11:01:24 2019

@author: mv gupta
"""
import re

while True:
    user=input("Enter email address ")
    if re.findall(r'^[0-9a-z_-]+@\w+\.\w{3,6}',user):
        li.append(user)
    if not user:
        break

li1=sorted(li)
print(set(li1))
        
    
    