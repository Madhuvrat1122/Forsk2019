# -*- coding: utf-8 -*-
"""
Created on Sat May 11 12:00:05 2019

@author: mv gupta
"""
import re
with open("simpsons_phone_book.txt","rt") as fp:
    li=fp.readlines()
    for item in li:
        li=list(item.split(" "))
        if li[1]=='Neu':
            if re.findall(r'^[J]+[a-z]',li[0]):
                print("{} {}".format(li[0],li[1]))
            
        