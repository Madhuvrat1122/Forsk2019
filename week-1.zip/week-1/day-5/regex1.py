# -*- coding: utf-8 -*-
"""
Created on Sat May 11 10:45:36 2019

@author: mv gupta
"""
import re
while True:
    user=input("Enter string")
    if re.findall(r'^[+-.]?\d{1,}\.\d{1,}',user):
        print(True)
    else:
        print(False)
    if not user:
        break
    
    
    